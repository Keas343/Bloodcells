for i=1:75
    imwrite(eval(['BW',num2str(i)]),strcat('GT_BloodImage_',num2str(i,'%05d'),'.jpg'));
end
save('GTworkspace.mat')